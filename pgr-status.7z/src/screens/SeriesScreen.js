import React, { Component, useEffect, useState } from 'react';
import { Text, View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import Dashboard from 'react-native-dashboard';
import health from '../api/health';

const SeriesScreen = () => {
  const card = ({ name }) => console.log('Card: ' + name);

  const [results, setResults] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      await health.get('/api/datasources/proxy/1/api/v1/series')
        .then((res) => {
            setResults(res.data.data);
            //console.log(res.data.data[1].instance);
        })
        .catch((e) => console.error(e));
    };

    const timer = setInterval(() => {
      fetchData();
    }, 5000);

    return () => clearTimeout(timer);
  }, []);
  
  return (
    <View style={styles.container}>
        <Text>{results.length}</Text>
        <FlatList 
            data={results}
            keyExtractor={result => result.instance}
            renderItem={({ item }) => {
                console.log(results);
                return <Text>{item.instance}</Text>
            }}
        />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
});

export default SeriesScreen;
